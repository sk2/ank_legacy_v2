# -*- coding: utf-8 -*-
"""
BGP Policy Parser
"""
__author__ = "\n".join(['Simon Knight'])
#    Copyright (C) 2009-2011 by Simon Knight, Hung Nguyen

__all__ = ['parse_policy']

import logging
LOG = logging.getLogger("ANK")

def parse_policy(network, net_file, default_asn = 1):

    return

