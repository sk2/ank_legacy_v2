from AutoNetkit.readwrite.graphml import *
from AutoNetkit.readwrite.pickle import *
from AutoNetkit.readwrite.bgp_parser import *
from AutoNetkit.readwrite.zoo import *

import AutoNetkit.readwrite.graphml
import AutoNetkit.readwrite.pickle
import AutoNetkit.readwrite.bgp_parser
import AutoNetkit.readwrite.zoo
