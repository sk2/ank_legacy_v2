import nose
nose.run()
print "tests"
