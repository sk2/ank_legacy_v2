try:
    import AutoNetkit.deploy.netkit_deploy
except:
    pass 

try:
    import AutoNetkit.deploy.dynagen_deploy
except:
    pass 

try:
    import AutoNetkit.deploy.olive_deploy
except:
    pass 

import AutoNetkit.deploy.netkit_allocate
import AutoNetkit.deploy.dynagen_deploy
import AutoNetkit.deploy.olive_deploy
