from AutoNetkit.readwrite.graphml import *
from AutoNetkit.readwrite.zoo import *

import AutoNetkit.readwrite.graphml
import AutoNetkit.readwrite.zoo
