from AutoNetkit.compiler.cbgpcompiler import *
from AutoNetkit.compiler.gns3compiler import *
from AutoNetkit.compiler.netkitcompiler import *

import AutoNetkit.compiler.cbgpcompiler
import AutoNetkit.compiler.gns3compiler
import AutoNetkit.compiler.netkitcompiler
