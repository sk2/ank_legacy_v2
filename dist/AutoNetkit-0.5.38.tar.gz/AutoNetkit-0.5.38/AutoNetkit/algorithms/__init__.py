from AutoNetkit.algorithms.autonomous_system import *
from AutoNetkit.algorithms.bgp import *
from AutoNetkit.algorithms.dns import *
from AutoNetkit.algorithms.inv_cap import *
from AutoNetkit.algorithms.ip import *
from AutoNetkit.algorithms.naming import *
from AutoNetkit.algorithms.optimise_igp import *

import AutoNetkit.algorithms.autonomous_system 
import AutoNetkit.algorithms.bgp 
import AutoNetkit.algorithms.dns 
import AutoNetkit.algorithms.inv_cap
import AutoNetkit.algorithms.ip 
import AutoNetkit.algorithms.naming 
import AutoNetkit.algorithms.optimise_igp
