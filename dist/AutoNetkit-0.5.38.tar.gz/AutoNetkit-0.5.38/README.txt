AutoNetkit
http://pypi.python.org/pypi/AutoNetkit/
